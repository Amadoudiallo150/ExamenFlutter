import 'package:flutter/material.dart';

class AproposPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'À propos',
            style: TextStyle(color: Colors.white), // Titre en blanc
          ),
        ),
        backgroundColor: Colors.green.shade900,
        iconTheme: IconThemeData(
          color: Colors.white, // Couleur de l'icône de retour
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
            Text(
            'À propos de myDMC',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.green.shade900, // Titre en vert foncé
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Bienvenue chez myDMC, votre destination en ligne pour l’achat d\'ordinateurs et de matériel informatique de qualité. Nous sommes passionnés par la technologie et nous nous engageons à offrir à nos clients une expérience d\'achat exceptionnelle, en mettant à leur disposition une large gamme de produits à la pointe de l\'innovation.',
            style: TextStyle(
              fontSize: 16,
              color: Colors.green.shade400, // Phrase en vert clair
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Notre Mission',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.green.shade900, // Sous-titre en vert foncé
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Chez myDMC, notre mission est de rendre la technologie accessible à tous en offrant des produits de haute qualité à des prix compétitifs. Nous croyons que chacun mérite le meilleur de la technologie moderne, c est pourquoi nous nous engageons à protéger vos investissements et à vous offrir un environnement sûr.',
            style: TextStyle(
            fontSize: 16,
            color: Colors.green.shade400, // Phrase en vert clair
          ),
        ),
        SizedBox(height: 16),
        Text(
          'Nos Valeurs',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.green.shade900, // Sous-titre en vert foncé
          ),
        ),
        SizedBox(height: 8),
        Text(
          '• Qualité : Nous sélectionnons rigoureusement nos produits pour garantir performance et fiabilité.\n'
              '• Service : Votre satisfaction est notre priorité. Nous nous efforçons de fournir un service client exceptionnel, avant, pendant et après votre achat.\n'
              '• Innovation : Nous sommes toujours à la recherche des dernières tendances technologiques pour vous offrir les meilleures solutions sur le marché.\n'
              '• Confiance : Acheter en ligne peut parfois être intimidant. Nous nous engageons à protéger vos informations et à vous offrir un environnement sécurisé.',
          style: TextStyle(
            fontSize: 16,
            color: Colors.green.shade400, // Phrase en vert clair
          ),
        ),
        SizedBox(height: 16),
        Text(
          'Pourquoi choisir myDMC ?',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.green.shade900, // Sous-titre en vert foncé
          ),
        ),
        SizedBox(height: 8),
        Text(
          '• Large sélection : Que vous soyez à la recherche d\'un ordinateur portable, d\'un PC de bureau, ou d\'accessoires, nous avons tout ce qu\'il vous faut.\n'
              '• Conseils d\'experts : Notre équipe est là pour vous aider à faire le meilleur choix en fonction de vos besoins.\n'
              '• Support client : Nous sommes là pour vous à chaque étape de votre achat. N\'hésitez pas à nous contacter à contact@dmccomputer.com ou au +221 77 336 77 87.',
          style: TextStyle(
            fontSize: 16,
            color: Colors.green.shade400, // Phrase en vert clair
          ),
        ),
        ],
      ),
    ),
    ),
    );
  }
}