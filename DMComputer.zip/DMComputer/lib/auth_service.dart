import 'package:flutter/material.dart';

class AuthService with ChangeNotifier {
  bool _isLoggedIn = false;
  String _username = '';
  String _email = '';

  bool get isLoggedIn => _isLoggedIn;
  String get username => _username;
  String get email => _email;

  void login(String username, String email) {
    _isLoggedIn = true;
    _username = username;
    _email = email;
    notifyListeners();
  }

  void logout() {
    _isLoggedIn = false;
    _username = '';
    _email = '';
    notifyListeners();
  }
}