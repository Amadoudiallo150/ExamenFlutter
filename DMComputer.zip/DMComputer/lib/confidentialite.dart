import 'package:flutter/material.dart';

class ConfidentialiePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Politique de confidentialité',
            style: TextStyle(color: Colors.white), // Titre en blanc
          ),
        ),
        backgroundColor: Colors.green.shade900,
        iconTheme: IconThemeData(
          color: Colors.white, // Couleur de l'icône de retour
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Politique de Confidentialité de myDMC',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade900, // Titre en vert foncé
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Dernière mise à jour : 13 Août 2024',
                style: TextStyle(
                  fontSize: 16,
                  fontStyle: FontStyle.italic,
                  color: Colors.green.shade400, // Phrase en vert clair
                ),
              ),
              SizedBox(height: 16),
              Text(
                '1. Collecte des informations',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade900, // Sous-titre en vert foncé
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Nous recueillons plusieurs types d\'informations pour vous fournir nos services, notamment :\n'
                    '• Votre nom et prénom\n'
                    '• Votre adresse e-mail\n'
                    '• Informations de paiement\n'
                    '• Adresse de livraison\n'
                    '• Informations sur votre appareil, y compris l’adresse IP, type d’appareil, et système d’exploitation.',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.green.shade400, // Phrase en vert clair
                ),
              ),
              SizedBox(height: 16),
              Text(
                '2. Utilisation des informations',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade900, // Sous-titre en vert foncé
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Nous utilisons vos informations pour :\n'
                    '• Gérer votre compte et traiter vos commandes.\n'
                    '• Faciliter la livraison de vos commandes.\n'
                    '• Améliorer votre expérience utilisateur en personnalisant nos services et nos offres.\n'
                    '• Vous informer sur l’état de vos commandes, les nouvelles offres ou les mises à jour.\n'
                    '• Répondre à vos demandes d\'assistance et améliorer notre service client.',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.green.shade400, // Phrase en vert clair
                ),
              ),
              SizedBox(height: 16),
              Text(
                '3. Partage des informations',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade900, // Sous-titre en vert foncé
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Nous respectons votre vie privée et ne partageons pas vos informations personnelles avec des tiers, sauf dans les cas suivants :\n'
                    '• Lorsque vous nous donnez votre autorisation explicite.\n'
                    '• Pour respecter la loi ou répondre à des demandes d\'autorités.\n'
                    '• Pour protéger nos droits ou nos biens.',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.green.shade400, // Phrase en vert clair
                ),
              ),
              SizedBox(height: 16),
              Text(
                '4. Sécurité',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade900, // Sous-titre en vert foncé
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Nous mettons en œuvre des mesures de sécurité appropriées pour protéger vos informations personnelles contre l\'accès non autorisé, la divulgation ou la destruction.',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.green.shade400, // Phrase en vert clair
                ),
              ),
              SizedBox(height: 16),
              Text(
                '5. Conservation des données',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade900, // Sous-titre en vert foncé
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Nous conservons vos informations personnelles aussi longtemps que nécessaire pour fournir nos services, respecter la loi, résoudre les litiges et faire respecter nos accords.',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.green.shade400, // Phrase en vert clair
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}