import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart.dart'; // Importez votre classe Cart

class CartPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<Cart>(context);

    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Mon Panier',
            style: TextStyle(color: Colors.white), // Texte en blanc
          ),
        ),
        backgroundColor: Colors.green.shade900, // Couleur de l'AppBar
        iconTheme: IconThemeData(
          color: Colors.white, // Couleur de l'icône de retour
        ),
      ),
      body: cart.items.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.shopping_cart, // Icône de panier
              size: 50, // Taille de l'icône
              color: Colors.grey, // Couleur de l'icône
            ),
            SizedBox(height: 20), // Espace sous l'icône
            Text(
              'Votre panier est vide',
              style: TextStyle(
                fontSize: 16, // Taille du texte
                color: Colors.grey, // Couleur du texte
              ),
            ),
          ],
        ),
      )
          : ListView.builder(
        itemCount: cart.items.length,
        itemBuilder: (context, index) {
          final product = cart.items[index];
          return ListTile(
            leading: Image.network(product.imageUrl, width: 50, height: 50),
            title: Text(product.name),
            subtitle: Text(product.price),
          );
        },
      ),
    );
  }
}
