import 'package:flutter/material.dart';

class FavoritesPage extends StatelessWidget {
  final List<Map<String,
      dynamic>> favoriteItems; // List to receive favorite items as maps

  FavoritesPage({Key? key, required this.favoriteItems}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Favoris',
            style: TextStyle(color: Colors.white),
          ),
        ),
        backgroundColor: Colors.green.shade900,
        iconTheme: IconThemeData(
          color: Colors.white, // Couleur de l'icône de retour
        ),
      ),
      body: favoriteItems.isEmpty
          ? Center(
        child: Text(
          'Aucun produit favori.',
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
      )
          : ListView.builder(
        itemCount: favoriteItems.length,
        itemBuilder: (context, index) {
          final item = favoriteItems[index];
          return _buildFavoriteCard(item['image'],
              item['title'],
              item['price']);
        },
      ),
    );
  }

  Widget _buildFavoriteCard(String imagePath, String title, String price) {
    return Container(
      width: 1, // Set a fixed width for the card
      margin: EdgeInsets.symmetric(vertical: 4, horizontal: 1),
      child: Card(
        elevation: 4,
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
              child: Image.asset(
                imagePath,
                height: 120, // Set a fixed height for the image
                fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(fontWeight: FontWeight.bold,
                        fontSize: 14), // Adjust font size if necessary
                  ),
                  SizedBox(height: 4),
                  Text(
                    price,
                    style: TextStyle(
                      color: Colors.green.shade900,
                      fontSize: 12, // Adjust font size if necessary
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}