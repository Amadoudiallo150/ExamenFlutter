import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl = 'https://dmcomputer.sn/wp-json/wc/v3/';
  final String consumerKey = 'ck_ce2175287f13be3edb8c8bb884e2e9051cfe08ad';
  final String consumerSecret = 'cs_c95c5bb6027fd918466dd18823a78a227a2d0b35';

  Future<List<dynamic>> fetchCategories() async {
    final response = await http.get(Uri.parse('${baseUrl}products/categories?consumer_key=$consumerKey&consumer_secret=$consumerSecret'));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load categories');
    }
  }

  Future<List<dynamic>> fetchProducts({int? category, String? search}) async {
    String url = '${baseUrl}products?consumer_key=$consumerKey&consumer_secret=$consumerSecret';

    if (category != null) {
      url += '&category=$category';
    }
    if (search != null && search.isNotEmpty) { // Ensure search is not null or empty
      url += '&search=$search';
    }

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load products');
    }
  }

  // Nouvelle méthode pour obtenir les détails d'un produit spécifique
  Future<Map<String, dynamic>> fetchProductDetails(int productId) async {
    final url = Uri.parse(
      '${baseUrl}products/$productId?consumer_key=$consumerKey&consumer_secret=$consumerSecret',
    );

    final response = await http.get(url);

    if (response.statusCode == 200) {
      return json.decode(response.body) as Map<String, dynamic>;
    } else {
      throw Exception('Failed to load product details');
    }
  }
}
