import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'auth_service.dart'; // Importez AuthService ici.
import 'home_page.dart'; // Importez HomePage ici.
import 'cart.dart'; // Importez Cart si nécessaire.

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthService()),
        ChangeNotifierProvider(create: (_) => Cart()), // Fournit l'accès au panier
      ],
      child: MyApp(),

    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title: 'Mon App',
      theme: ThemeData(
        primarySwatch: Colors.blue, // Définissez un thème global.
      ),
      home: HomePageContent(), // Remplacez par votre page d'accueil.
    );
  }
}
