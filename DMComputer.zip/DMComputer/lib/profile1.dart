import 'package:dmcapp/profile.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'auth_service.dart'; // Importez votre AuthService

class Profile1Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final authService = Provider.of<AuthService>(context);

    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Mon Profil',
            style: TextStyle(color: Colors.white),
          ),
        ),
        backgroundColor: Colors.green.shade900,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Ajout d'une image de profil
            Center(
              child: Container(
                width: 100, // Largeur de l'image
                height: 100, // Hauteur de l'image
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.grey.shade200, // Couleur de fond si pas d'image
                ),
              ),
            ),
            SizedBox(height: 20),
            Text('Informations Personnelles', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            // Affichez les informations de l'utilisateur
            Text('Nom: ${authService.username}'),
            Text('Email: ${authService.email}'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                _showDeleteAccountDialog(context);
              },
              child: Text('Supprimer mon compte'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                // Déconnexion
                authService.logout();
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => ProfilePage()), // Remplacez par votre page de connexion
                );
              },
              child: Text('Déconnexion'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade900),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteAccountDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Confirmation"),
          content: Text("Êtes-vous sûr de vouloir supprimer votre compte ?"),
          actions: <Widget>[
            TextButton(
              child: Text("Annuler"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text("Supprimer"),
              onPressed: () {
                // Ajoutez la logique de suppression de compte ici
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}