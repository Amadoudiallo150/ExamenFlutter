import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart.dart'; // Importez votre classe Cart
import 'cart_page.dart'; // Importez votre page de panier
import 'api_service.dart';
import 'models/product.dart'; // Importez votre modèle Product

class ProductDetailPage extends StatefulWidget {
  final int productId;

  ProductDetailPage({required this.productId});

  @override
  _ProductDetailPageState createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  Map<String, dynamic>? productDetails;

  @override
  void initState() {
    super.initState();
    _fetchProductDetails();
  }

  // Fonction pour récupérer les détails du produit
  Future<void> _fetchProductDetails() async {
    ApiService apiService = ApiService();
    try {
      productDetails = await apiService.fetchProductDetails(widget.productId);
      setState(() {}); // Met à jour l'état après la récupération des données.
    } catch (e) {
      print('Erreur: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (productDetails == null) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Détails du produit'),
        ),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(productDetails!['name']),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Affichage de l'image
            Image.network(
              productDetails!['images'][0]['src'],
              height: 250,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),

            // Nom du produit
            Text(
              productDetails!['name'],
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),

            // Prix du produit
            Text(
              'Prix: ${productDetails!['price']}',
              style: TextStyle(fontSize: 20, color: Colors.red),
            ),
            SizedBox(height: 16),

            // Description du produit
            Text(
              productDetails!['description'] ?? 'Aucune description disponible.',
            ),
            Spacer(),

            // Bouton Ajouter au Panier
            ElevatedButton(
              onPressed: () {
                // Test: Affichez un message pour détecter le clic
                print('Clic détecté sur Ajouter au Panier');

                // Ajout du produit au panier
                final cart = Provider.of<Cart>(context, listen: false);
                cart.addProduct(
                  Product(
                    id: widget.productId,
                    name: productDetails!['name'],
                    imageUrl: productDetails!['images'][0]['src'],
                    price: productDetails!['price'],
                  ),
                );
                print('Produit ajouté au panier : ${cart.items.length}');

                // Affiche une notification
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Produit ajouté au panier!')),
                );

                // Redirige vers la page panier
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CartPage()),
                );
              },
              child: Text('Ajouter au Panier'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            ),
          ],
        ),
      ),
    );
  }
}
