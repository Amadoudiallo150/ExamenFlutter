import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart'; // Import CarouselSlider
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:provider/provider.dart';
import 'auth_service.dart'; // Importez votre AuthService
import 'cart_page.dart';
import 'favorites_page.dart';
import 'profile.dart';
import 'apropos_page.dart';
import 'confidentialite.dart';
import 'research.dart';
import 'profile1.dart'; // Importez votre page de profil 1

// Ajoutez la classe ApiService
class ApiService {
  final String baseUrl = 'https://dmcomputer.sn/wp-json/wc/v3/';
  final String consumerKey = 'ck_ce2175287f13be3edb8c8bb884e2e9051cfe08ad';
  final String consumerSecret = 'cs_c95c5bb6027fd918466dd18823a78a227a2d0b35';

  Future<List<dynamic>> fetchCategories() async {
    final response = await http.get(Uri.parse('${baseUrl}products/categories?consumer_key=$consumerKey&consumer_secret=$consumerSecret'));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load categories');
    }
  }

  Future<List<dynamic>> fetchProducts({int? category, String? search}) async {
    String url = '${baseUrl}products?consumer_key=$consumerKey&consumer_secret=$consumerSecret';
    if (category != null) {
      url += '&category=$category';
    }
    if (search != null && search.isNotEmpty) {
      url += '&search=$search';
    }

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load products');
    }
  }

  Future<Map<String, dynamic>> fetchProductDetails(int productId) async {
    final response = await http.get(Uri.parse('${baseUrl}products/$productId?consumer_key=$consumerKey&consumer_secret=$consumerSecret'));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load product details');
    }
  }
}

class HomePageContent extends StatefulWidget {
  @override
  _HomePageContentState createState() => _HomePageContentState();
}

class _HomePageContentState extends State<HomePageContent> {
  String selectedCategory = 'Toutes';
  List<Map<String, dynamic>> favoriteItems = [];
  List<dynamic> categories = [];
  List<dynamic> products = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData({int? categoryId, String? searchQuery}) async {
    ApiService apiService = ApiService();
    try {
      categories = await apiService.fetchCategories();
      products = await apiService.fetchProducts(category: categoryId, search: searchQuery);
      setState(() {});
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    List<dynamic> currentItems = products;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade900,
        title: Center(child: Text('DMComputer.sn', style: TextStyle(color: Colors.white))),
        leading: Builder(
          builder: (context) => IconButton(
            icon: Icon(Icons.menu, color: Colors.white),
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart, color: Colors.white),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => CartPage()));
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: Column(
          children: [
            Container(
              height: 120,
              decoration: BoxDecoration(
                color: Colors.green.shade900,
                image: DecorationImage(
                  image: AssetImage('images/logo.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            _buildDrawerItem(Icons.home, 'Accueil', context, HomePageContent()),
            _buildDrawerItem(Icons.favorite_border, 'Favoris', context, FavoritesPage(favoriteItems: favoriteItems)),
            _buildDrawerItem(Icons.search, 'Recherche', context, ResearchPage()),
            _buildDrawerItem(Icons.shopping_cart, 'Panier', context, CartPage()),
            _buildDrawerItem(Icons.account_circle, 'Mon Compte', context, ProfilePage()),
            _buildDrawerItem(Icons.info, 'À propos', context, AproposPage()),
            _buildDrawerItem(Icons.lock, 'Politique de confidentialité', context, ConfidentialiePage()),
            Spacer(),
            Container(
              margin: EdgeInsets.symmetric(vertical: 16.0),
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: Icon(Icons.logout, color: Colors.white),
                label: Text('Déconnexion', style: TextStyle(color: Colors.white)),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade900),
                onPressed: () {
                  Provider.of<AuthService>(context, listen: false).logout();
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => ProfilePage()));
                },
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            // Ajoutez le CarouselSlider ici
            CarouselSlider(
              options: CarouselOptions(
                height: 150.0,
                autoPlay: true,
                enlargeCenterPage: true,
                enableInfiniteScroll: true,
                viewportFraction: 1.5,
              ),
              items: [
                'images/image1.jpg',
                'images/ordi1.jpeg',
                'images/image1.jpg',
                'images/image1.jpg',
              ].map((item) {
                return Container(
                  margin: EdgeInsets.symmetric(horizontal: 5.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8.0),
                    child: Image.asset(
                      item,
                      fit: BoxFit.cover,
                      width: 1000.0,
                    ),
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Catégories', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text('Voir tout', style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: categories.map((category) {
                  return _buildCategoryButton(category['name'], category['id']);
                }).toList(),
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: GridView.builder(
                physics: BouncingScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 1.2,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 4,
                ),
                itemCount: currentItems.length,
                itemBuilder: (context, index) {
                  var product = currentItems[index];
                  return _buildProductCard(
                    context,
                    product['images'][0]['src'],
                    product['name'],
                    product['price'],
                    product['id'], // Passer l'ID du produit
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.grey,
        unselectedItemColor: Colors.grey,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home, size: 24), label: 'Accueil'),
          BottomNavigationBarItem(icon: Icon(Icons.search, size: 24), label: 'Recherche'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart, size: 24), label: 'Panier'),
          BottomNavigationBarItem(icon: Icon(Icons.person, size: 24), label: 'Compte'),
        ],
        onTap: (index) {
          switch (index) {
            case 0:
              break;
            case 1:
              Navigator.push(context, MaterialPageRoute(builder: (context) => ResearchPage()));
              break;
            case 2:
              Navigator.push(context, MaterialPageRoute(builder: (context) => CartPage()));
              break;
            case 3:
              if (Provider.of<AuthService>(context, listen: false).isLoggedIn) {
                Navigator.push(context, MaterialPageRoute(builder: (context) => Profile1Page()));
              } else {
                Navigator.push(context, MaterialPageRoute(builder: (context) => ProfilePage()));
              }
              break;
          }
        },
      ),
    );
  }

  Widget _buildCategoryButton(String label, int categoryId) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: ElevatedButton(
        onPressed: () {
          setState(() {
            selectedCategory = label;
          });
          _loadData(categoryId: categoryId);
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: selectedCategory == label ? Colors.green.shade900 : Colors.white,
          side: BorderSide(color: Colors.green.shade900),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selectedCategory == label ? Colors.white : Colors.green.shade900,
          ),
        ),
      ),
    );
  }

  Widget _buildProductCard(BuildContext context, String imagePath, String title, String price, int productId) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => ProductDetailPage(productId: productId)));
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: Stack(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
                  child: Image.network(
                    imagePath,
                    height: 200,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (BuildContext context, Object error, StackTrace? stackTrace) {
                      return Center(child: Text('Erreur de chargement de l\'image'));
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                  child: Column(
                    children: [
                      Text(
                        title,
                        style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 4),
                      Text(
                        price,
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem(IconData icon, String title, BuildContext context, Widget? page) {
    return ListTile(
      leading: Icon(icon, color: Colors.grey.shade700),
      title: Text(title),
      onTap: () {
        Navigator.pop(context);
        if (page != null) {
          Navigator.push(context, MaterialPageRoute(builder: (context) => page));
        }
      },
    );
  }
}

// Page de détails du produit
class ProductDetailPage extends StatefulWidget {
  final int productId;

  ProductDetailPage({required this.productId});

  @override
  _ProductDetailPageState createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  Map<String, dynamic>? productDetails;

  @override
  void initState() {
    super.initState();
    _fetchProductDetails();
  }

  Future<void> _fetchProductDetails() async {
    ApiService apiService = ApiService();
    try {
      productDetails = await apiService.fetchProductDetails(widget.productId);
      setState(() {});
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (productDetails == null) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Détails du produit'),
        ),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(productDetails!['name']),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(
              productDetails!['images'][0]['src'],
              height: 250,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),
            Text(
              productDetails!['name'],
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'Price: ${productDetails!['price']}',
              style: TextStyle(fontSize: 20, color: Colors.red),
            ),
            SizedBox(height: 16),
            Text(productDetails!['description'] ?? 'No description available.'),
            Spacer(),
            ElevatedButton(
              onPressed: () {
                // Ajoutez le produit au panier (implémentez cette fonction selon vos besoins)
              },
              child: Text('Ajouter au Panier'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade900),
            ),
          ],
        ),
      ),
    );
  }
}