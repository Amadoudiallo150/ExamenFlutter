import 'package:flutter/material.dart';
import 'package:dmcapp/api_service.dart' as api_service; // Use a prefix for ApiService
import 'package:dmcapp/home_page.dart'; // Keep the import for HomePage

class ResearchPage extends StatefulWidget {
  @override
  _ResearchPageState createState() => _ResearchPageState();
}

class _ResearchPageState extends State<ResearchPage> {
  final TextEditingController _searchController = TextEditingController();
  List<dynamic> _searchResults = [];
  bool _isLoading = false;

  void _searchProducts() async {
    setState(() {
      _isLoading = true;
      _searchResults.clear();
    });

    api_service.ApiService apiService = api_service.ApiService(); // Use the prefixed ApiService
    try {
      final results = await apiService.fetchProducts(search: _searchController.text);
      setState(() {
        _searchResults = results;
      });
    } catch (e) {
      print(e);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text(
            'Rechercher un produit DMC',
            style: TextStyle(color: Colors.white),
          ),
        ),
        backgroundColor: Colors.green.shade900,
        iconTheme: IconThemeData(
          color: Colors.white,
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Rechercher un produit DMC',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.green.shade900),
                ),
              ),
              onSubmitted: (value) => _searchProducts(),
            ),
          ),
          _isLoading
              ? Center(child: CircularProgressIndicator())
              : Expanded(
            child: _searchResults.isEmpty
                ? Center(
              child: Text(
                'Aucun résultat trouvé',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey,
                ),
              ),
            )
                : ListView.builder(
              itemCount: _searchResults.length,
              itemBuilder: (context, index) {
                var product = _searchResults[index];
                return ListTile(
                  title: Text(product['name']),
                  subtitle: Text(product['price']),
                  leading: Image.network(
                    product['images'][0]['src'],
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                  ),
                  onTap: () {
                    // Navigate to product details page if needed
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}